// Jesse James
// 3-2-2013
// VFW Project 4 1302

var json = {
	"game1": {
		"catergory": ["Game Catergory: ", "Adventure"],
		"name": ["Game Name: ", "The Legend of Zelda: Skyward Sword"],
		"publisher": ["Game Publisher: ", "Nintendo"],
		"release": ["Game Release: ", "2011-11-20"],
		"rate": ["Game Rating: ", "10"],
		"console": ["Game Console: ", ["Wii"]],
		"comments": ["Comments: ", "This game was awesome!"]
	},
	"game2": {
		"catergory": ["Game Catergory: ", "First Person Shooter"],
		"name": ["Game Name: ", "Halo 4"],
		"publisher": ["Game Publisher: ", "Microsoft"],
		"release": ["Game Release: ", "2012-11-6"],
		"rate": ["Game Rating: ", "8"],
		"console": ["Game Console: ", ["Xbox 360"]],
		"comments": ["Comments: ", "Good for a shooter, much better than I expected it to be."]
	},
		"game3": {
		"catergory": ["Game Catergory: ", "Racing"],
		"name": ["Game Name: ", "Dirt 3"],
		"publisher": ["Game Publisher: ", "Code Masters"],
		"release": ["Game Release: ", "2011-05-24"],
		"rate": ["Game Rating: ", "9"],
		"console": ["Game Console: ", ["Xbox 360","Playstation 3"]],
		"comments": ["Comments: ", "This game had a lot of thought put into it and is a lot of fun on my racing wheel."]
	}
}